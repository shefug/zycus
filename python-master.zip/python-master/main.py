#!/usr/bin/python
import test
from test import sum


total = sum( 10, 20 );
print "Outside the function : ", total 
