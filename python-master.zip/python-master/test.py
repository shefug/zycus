#!/usr/bin/python
path = '/home/test'
name='test'
head = path.split()
print head


#def parrot(voltage, state='a stiff', action='voom', type='Norwegian Blue'):
 #   print("-- This parrot wouldn't", action)
  #  print("if you put", voltage, "volts through it.")
   # print("-- Lovely plumage, the", type)
   # print("-- It's", state, "!")


#parrot(voltage=5.0, 'dead')

def sum( arg1, arg2 ):
   # Add both the parameters and return them."
   total = arg1 + arg2
   print "Inside the function : ", total
   return total;

#total = sum( 10, 20 );
#print "Outside the function : ", total
